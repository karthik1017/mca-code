#include<stdio.h>
#include<stdlib.h>
#include <time.h>

void mergeing(long int arr[], int s, int m, int r);
void breaking(long int arr[], int l, int r);
void quick_sort(long int arr[], int low, int high);
void generate_random(long int a[],long int num);
void store_to_file1(double sel_time[],long int inputs[]);
void store_to_file(double bub_time[], long int inputs[]);

int main(void)
{
	long int a[160000],b[160000],num,i;
    long int inputs[] = {5, 50, 500, 5000,10000,15000,20000,30000,40000,60000,70000,80000,90000};
    double mer_time[18],quick_time[18];
    printf("for merge sort: \n");
    for(int x=0;x<13;x++)
    {
      num=inputs[x];
      generate_random(a,num);
      clock_t begin = clock();
      breaking(a,0,num);
      clock_t end = clock();
      mer_time[x] = (double)(end - begin) / CLOCKS_PER_SEC;
      printf("Time taken for bubble sort of input size %ld: %f\n", inputs[x], mer_time[x]);
    }

    printf("for quick_sort: \n");
    for(int x=0;x<13;x++)
    {
      num=inputs[x];
      generate_random(b,num);
      clock_t begin = clock();
      quick_sort(b, 0, num);
      clock_t end = clock();
      quick_time[x] = (double)(end - begin) / CLOCKS_PER_SEC;
      printf("Time taken for bubble sort of input size %ld: %f\n", inputs[x], quick_time[x]);
    }

    store_to_file(mer_time,inputs);
    store_to_file1(quick_time,inputs);
    system("gnuplot");
    system("gnuplot");
    return 0;
}

void generate_random(long int a[],long int num)
{
    for(int i=0;i<num;i++)
    {
        a[i]=rand()%10000;
    }
}

void breaking(long int arr[], int l, int r)
{
    int m;
    if (l < r)
    {
        m = l+(r-l)/2;
        breaking(arr, l, m);
        breaking(arr, m+1, r);
        mergeing(arr, l, m, r);
    }
}

void mergeing(long int arr[], int l, int m, int r)
{
    int i = 0,j = 0, k;
    int n1 = m - l + 1,n2 =  r - m;
    int L[n1], R[n2];
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1+ j];
    k = l; 
    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void quick_sort(long int arr[], int low, int high)
{
    int pivot, i, j, temp;
    if (low < high)
    {
        pivot = low;
        i = low;
        j = high;
        while (i < j) 
        {
            while (arr[i] <= arr[pivot] && i <= high)
            {
                i++;
            }
            while (arr[j] > arr[pivot] && j >= low)
            {
                j--;
            }
            if (i < j)
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        temp = arr[j];
        arr[j] = arr[pivot];
        arr[pivot] = temp;
        quick_sort(arr, low, j - 1);
        quick_sort(arr, j + 1, high);
    }
}

void store_to_file1(double sel_time[],long int inputs[])
{
    FILE *fptr1;

    int i;

    fptr1 = fopen("quick.txt", "w");
     
    if (fptr1 == NULL)
    {
        printf("File does not exists \n");
        return;
    }

    for(i = 0; i < 13; i++){
        fprintf(fptr1, "%ld  %lf  \n", inputs[i], sel_time[i]);
    }

    fclose(fptr1);
}

void store_to_file(double sel_time[], long int inputs[])
{
    FILE *fptr;

    int i;

    fptr = fopen("mer.txt", "w");
     
    if (fptr == NULL)
    {
        printf("File does not exists \n");
        return;
    }

    for(i = 0; i < 13; i++){
        fprintf(fptr, "%ld  %lf  \n", inputs[i], sel_time[i]);
    }

    fclose(fptr);
}